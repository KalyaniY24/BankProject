using bankproject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using Microsoft.AspNetCore.Authorization;

namespace pro1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        BankdbContext dc = new BankdbContext();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        

        public IActionResult Privacy()
        {
            return View();
        }
        
        [HttpPost]
        public IActionResult Privacy(Userdetail ob)
        {

            var res = (from t in dc.Userdetails
                       where t.Username == ob.Username && t.Accesscode == ob.Accesscode
                       select t).Count();
            if (res > 0)
            {
                return RedirectToAction("menu");
            }

            else
            {
                ViewData["e"] = "Invalid credentials";
                return RedirectToAction("Index");
            }
            return View();
        }
        
        public IActionResult menu()
        {
            return View();
        }
        public IActionResult reg()
        {
            return View();
        }


        [HttpPost]
        public IActionResult reg(Userdetail ob)
        {
            dc.Userdetails.Add(ob);
            int i = dc.SaveChanges();
            if (i > 0)
                ViewData["e"] = "record inserted";
            else
                ViewData["e"] = "Insertion failed";
            return View();
        }
        public IActionResult tra()
        {
            return View();

        }

        [HttpPost]
        public IActionResult tra(Transaction ob)
        {
           
            dc.Transactions.Add(ob);
            int i = dc.SaveChanges();
            if (i > 0)
                ViewData["e"] = "record inserted";
            else
                ViewData["e"] = "Insertion failed";
            return View();
        }
        public IActionResult statement()
        {
            return View();
        }

        [HttpPost]
        public IActionResult statement(string ser)
        {
           
            int s = int.Parse(ser);
            
            var r = from t in dc.Transactions
                    where t.Accno == s
                    select t;
            
            return View(r.ToList());
    
            
        }

            public IActionResult closeacc()
        {
            return View();
        }


        [HttpPost]
        public IActionResult closeacc(Userdetail ob)
        {
            //logic to deletre trsanction

            var r = from t in dc.Transactions
                    where t.Accno == ob.Accountno
                    select t;
            foreach (var t in r)
            {
                dc.Transactions.Remove(t);
            }
            dc.SaveChanges();

            var res = (from t in dc.Userdetails
                       where t.Accountno == ob.Accountno && t.Accesscode == ob.Accesscode
                       select t).Count();
            if (res > 0)
            {
                dc.Userdetails.Remove(ob);
                dc.SaveChanges();
            }

            else
            {
                ViewData["e"] = "Invalid credentials";
            }
            return View();
            

     
            
        }
        [HttpGet]
        public ActionResult admin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult admin(IFormCollection frmobj) //FormCollection  
        {
            string username = frmobj["userid"];
            string password = frmobj["pwd"];
            if (username == "Admin" && password == "123456")
            {
				return RedirectToAction("adminmenu");
				ViewData["e"] = "valid credentials";
            }
            else
            {
                ViewData["e"] = "Invalid credentials";
            }
            return View();
        }

       
        public IActionResult custdetails()
        {

            var r = from t in dc.Userdetails
                    select t;

            return View(r.ToList());
        }

        [HttpPost]
        public IActionResult custdetails(string Statustype, string abc)
        {

            int i = int.Parse(abc);
            var res = (from t in dc.Userdetails
                      where t.Accountno == i 
                      select t).First();

            res.Statustype = Statustype;
            dc.Userdetails.Update(res);
            dc.SaveChanges();
            return RedirectToAction("custdetails");
        }


        public IActionResult trareport()
        {
            var r = from t in dc.Transactions
                    select t;
            return View(r.ToList());
        }
        public IActionResult adminmenu()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
