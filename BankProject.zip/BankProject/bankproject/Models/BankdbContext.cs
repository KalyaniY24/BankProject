using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace bankproject.Models;

public partial class BankdbContext : DbContext
{
    public BankdbContext()
    {
    }

    public BankdbContext(DbContextOptions<BankdbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Transaction> Transactions { get; set; }

    public virtual DbSet<Userdetail> Userdetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=oracle;Database=bankdb;uid=sa;pwd=Root123$;TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.Tid).HasName("PK__transact__DC105B0F68D39731");

            entity.ToTable("transactions");

            entity.Property(e => e.Tid).HasColumnName("tid");
            entity.Property(e => e.Accno).HasColumnName("accno");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.Billingtype)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("billingtype");

            entity.HasOne(d => d.AccnoNavigation).WithMany(p => p.Transactions)
                .HasForeignKey(d => d.Accno)
                .HasConstraintName("FK__transacti__accno__38996AB5");
        });

        modelBuilder.Entity<Userdetail>(entity =>
        {
            entity.HasKey(e => e.Accountno).HasName("PK__userdeta__F2076ECDFC67859A");

            entity.ToTable("userdetails");

            entity.Property(e => e.Accountno).HasColumnName("accountno");
            entity.Property(e => e.Accesscode).HasColumnName("accesscode");
            entity.Property(e => e.Accounttype)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("accounttype");
            entity.Property(e => e.Mobileno).HasColumnName("mobileno");
            entity.Property(e => e.Statustype)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("statustype");
            entity.Property(e => e.Useraddress)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("useraddress");
            entity.Property(e => e.Username)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("username");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
