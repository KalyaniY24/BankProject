namespace bankproject.Models
{
    public class adminlog
    {
        public string userid { get; set; }
        public string pwd { get; set; }
    }
}
