using System;
using System.Collections.Generic;

namespace bankproject.Models;

public partial class Transaction
{
    public int? Accno { get; set; }

    public string? Billingtype { get; set; }

    public long? Amount { get; set; }

    public int Tid { get; set; }

    public virtual Userdetail? AccnoNavigation { get; set; }
}
