using System;
using System.Collections.Generic;

namespace bankproject.Models;

public partial class Userdetail
{
    public int Accountno { get; set; }

    public string? Username { get; set; }

    public int? Accesscode { get; set; }

    public int? Mobileno { get; set; }

    public string? Useraddress { get; set; }

    public string? Accounttype { get; set; }

    public string? Statustype { get; set; }

    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
