﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace bankproject.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "userdetails",
                columns: table => new
                {
                    accountno = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    username = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    accesscode = table.Column<int>(type: "int", nullable: true),
                    mobileno = table.Column<int>(type: "int", nullable: true),
                    useraddress = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    accounttype = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    statustype = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__userdeta__F2076ECDFC67859A", x => x.accountno);
                });

            migrationBuilder.CreateTable(
                name: "transactions",
                columns: table => new
                {
                    tid = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    accno = table.Column<int>(type: "int", nullable: true),
                    billingtype = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    amount = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__transact__DC105B0F68D39731", x => x.tid);
                    table.ForeignKey(
                        name: "FK__transacti__accno__38996AB5",
                        column: x => x.accno,
                        principalTable: "userdetails",
                        principalColumn: "accountno");
                });

            migrationBuilder.CreateIndex(
                name: "IX_transactions_accno",
                table: "transactions",
                column: "accno");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "transactions");

            migrationBuilder.DropTable(
                name: "userdetails");
        }
    }
}
